
//#include <DHTlib.h>
#include <DHT.h>

//dht DHT;

#define DHTPIN 10     // what pin we're connected to
#define DHTTYPE DHT11   // DHT 11 

DHT dht(DHTPIN, DHTTYPE, 6);


void dht_command() {
    char* arg = sCmd.next();
    if(arg == NULL) {
        argument_error();
        return;
    }
    int dht_type = atoi(arg);
    arg = sCmd.next();
    if(arg == NULL) {
        argument_error();
        return;
    }
    int dht_pin = atoi(arg);

    int chk;
    // just the dht 11 sensor read function is different

    DHT dht(dht_pin, dht_type,6);

    float h = dht.readHumidity();
    // Read temperature as Celsius
    float t = dht.readTemperature();

    // Check if any reads failed and exit early (to try again).
    if (isnan(h) || isnan(t)) {
    Serial.println("Failed to read from DHT sensor!");
    //return;
    }
    else {
   
            Serial.print("ACK ");
            Serial.print(dht.readTemperature());
            Serial.write(' ');
            Serial.print(dht.readHumidity());
            Serial.print("\r\n");
    }
    
 

/*    

    if (dht_type == 11) {
        chk = DHT.read11(dht_pin);
    } else {
        chk = DHT.read(dht_pin);
    }

    switch (chk) {
        case DHTLIB_OK:
            Serial.print("ACK ");
            Serial.print(DHT.temperature, 1);
            Serial.write(' ');
            Serial.print(DHT.humidity, 1);
            Serial.print("\r\n");
            break;
        case DHTLIB_ERROR_CHECKSUM:
            Serial.print("ERR checksum_error\r\n");
            break;
        case DHTLIB_ERROR_TIMEOUT:
            Serial.print("ERR timeout_error\r\n");
            break;
        default:
            Serial.print("ERR unknown_error\r\n");
            break;
    }
*/
}
