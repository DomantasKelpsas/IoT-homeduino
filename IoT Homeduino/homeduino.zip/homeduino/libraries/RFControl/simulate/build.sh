#!/bin/sh
g++ -DRF_CONTROL_SIMULATE_ARDUINO=1 -Wall simulate.cpp -o simulate
