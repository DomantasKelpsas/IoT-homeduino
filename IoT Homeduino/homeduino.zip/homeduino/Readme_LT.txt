nauja Homeduino versija su DHT biblioteka.
DHT 11 prijungtas prie A3(17 pimatic), jei keisti reikia - modifikuoti kod�.